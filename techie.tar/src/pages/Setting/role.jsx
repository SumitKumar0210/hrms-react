import React, { useEffect, useMemo, useState } from "react";
import { Container, Button, Badge, Modal, Form } from "react-bootstrap";
import DataTable from "react-data-table-component";
import { FiEdit, FiPlusCircle } from "react-icons/fi";
import { LuTrash2 } from "react-icons/lu";
import { Formik } from "formik";
import * as Yup from "yup";
import {
  getRoles,
  storeRole,
  updateRole,
  deleteRole,
} from "./slice/roleSlice";
import { FaUserShield } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

/* ================= VALIDATION ================= */
const validationSchema = Yup.object({
  name: Yup.string().required("Role Name is required"),
});

/* ================= COMPONENT ================= */
const Roles = () => {
  const dispatch = useDispatch();
  const { data = [], loading } = useSelector((state) => state.role);

  const [search, setSearch] = useState("");
  const [show, setShow] = useState(false);
  const [editRow, setEditRow] = useState(null);
  const [showDelete, setShowDelete] = useState(false);
  const [deleteRow, setDeleteRow] = useState(null);
  const navigate = useNavigate()
  const { hasPermission, hasAnyPermission } = useAuth();

  /* ================= FETCH ================= */
  useEffect(() => {
    dispatch(getRoles());
  }, [dispatch]);

  /* ================= SEARCH ================= */
  const filteredData = useMemo(() => {
    return data.filter((item) =>
      item.name.toLowerCase().includes(search.toLowerCase())
    );
  }, [data, search]);

  /* ================= TABLE COLUMNS ================= */
  const columns = useMemo(() => {
    const baseColumn = [
      {
        name: "Role Name",
        selector: (row) => row.name,
        sortable: true,
      },
      {
        name: "Guard",
        selector: (row) => row.guard_name,
      },
    ];

    if (hasAnyPermission(['roles_permission.update', 'roles_permission.delete'])) {
      baseColumn.push({
        name: "Actions",
        cell: (row) => (
          <div className="d-flex gap-2">

            {/* EDIT */}
            {hasPermission('roles_permission.update') && (
              <Button
                size="sm"
                variant="outline-primary"
                onClick={() => handleEdit(row)}
              >
                <FiEdit size={16} />
              </Button>
            )}

            {/* PERMISSION */}
            {hasPermission('roles_permission.update') && (
              <Button
                size="sm"
                variant="outline-warning"
                onClick={() => handleNavigation(row.id)}
              >
                <FaUserShield size={16} />
              </Button>
            )}

            {/* DELETE */}
            {hasPermission('roles_permission.delete') && (
              <Button
                size="sm"
                variant="outline-danger"
                onClick={() => {
                  setDeleteRow(row);
                  setShowDelete(true);
                }}
              >
                <LuTrash2 size={16} />
              </Button>
            )}

          </div>
        ),
        ignoreRowClick: true,
        center: true,
      });
    }

    return baseColumn;

  }, [hasPermission, hasAnyPermission]);

  /* ================= HANDLERS ================= */
  const handleEdit = (row) => {
    setEditRow(row);
    setShow(true);
  };

  const handleAddNew = () => {
    setEditRow(null);
    setShow(true);
  };

  const confirmDelete = () => {
    if (!deleteRow) return;

    dispatch(deleteRole(deleteRow.id));
    setShowDelete(false);
    setDeleteRow(null);
  };

  const handleNavigation = (id) => {

    navigate(`/settings/${id}/fetch-permissions`)
  }

  /* ================= UI ================= */
  return (
    <>
      <Container fluid>
        {/* Header */}
        <div className="d-flex justify-content-between align-items-center border-bottom pb-2">
          <h5 className="mb-0 fw-normal fs-6">Roles</h5>
          {hasPermission('roles_permission.create') && (

            <Button variant="primary" size="sm" onClick={handleAddNew}>
              <FiPlusCircle className="me-2" />
              Create Role
            </Button>
          )}
        </div>

        {/* Search */}
        <div className="d-flex justify-content-between align-items-center mb-3 mt-3">
          <h6 className="mb-0">Roles List</h6>

          <Form.Control
            type="text"
            placeholder="Search role..."
            style={{ maxWidth: 260 }}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Table */}
        <DataTable
          columns={columns}
          data={filteredData}
          pagination
          progressPending={loading}
          highlightOnHover
          responsive
          persistTableHead
        />
      </Container>

      {/* ================= MODAL ================= */}
      <Modal show={show} onHide={() => setShow(false)} centered>
        <Formik
          initialValues={{
            name: editRow?.name || "",
          }}
          validationSchema={validationSchema}
          enableReinitialize
          onSubmit={(values, actions) => {
            if (editRow) {
              dispatch(updateRole({ ...values, id: editRow.id }));
            } else {
              dispatch(storeRole(values));
            }

            actions.resetForm();
            setShow(false);
          }}
        >
          {({
            handleSubmit,
            handleChange,
            values,
            errors,
            touched,
            isSubmitting,
          }) => (
            <Form onSubmit={handleSubmit} noValidate>
              <Modal.Header closeButton>
                <Modal.Title className="h6 fw-normal">
                  {editRow ? "Edit Role" : "Create Role"}
                </Modal.Title>
              </Modal.Header>

              <Modal.Body>
                <Form.Group>
                  <Form.Label>Role Name</Form.Label>

                  <Form.Control
                    name="name"
                    placeholder="Enter Role Name"
                    value={values.name}
                    onChange={handleChange}
                    isInvalid={touched.name && !!errors.name}
                  />

                  <Form.Control.Feedback type="invalid">
                    {errors.name}
                  </Form.Control.Feedback>
                </Form.Group>
              </Modal.Body>

              <Modal.Footer className="custom">
                <Button
                  variant=""
                  onClick={() => setShow(false)}
                  className="btn-link danger w-100"
                >
                  Close
                </Button>

                <Button
                  variant=""
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-link success w-100"
                >
                  {editRow ? "Update" : "Submit"}
                </Button>
              </Modal.Footer>
            </Form>
          )}
        </Formik>
      </Modal>

      {/* ================= DELETE CONFIRM ================= */}
      <Modal show={showDelete} onHide={() => setShowDelete(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title className="h6 fw-bold text-dark">
            Confirm Delete
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <p className="mb-0">
            Are you sure you want to delete role{" "}
            <strong>{deleteRow?.name}</strong>?
          </p>
        </Modal.Body>

        <Modal.Footer className="custom">
          <Button
            variant=""
            onClick={() => setShowDelete(false)}
            className="btn-link w-100"
          >
            Cancel
          </Button>

          <Button
            variant=""
            onClick={confirmDelete}
            className="btn-link danger w-100"
          >
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default Roles;